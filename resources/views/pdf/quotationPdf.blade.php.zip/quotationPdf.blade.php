<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo public_path('Asset/css/pdfStyle.css'); ?>">
    <title>Quotation Pdf</title>
</head>
<body>
<div class="container">
    <table class="pdf-body" style="width: 100%;">
        <tr>
            <td style="width: 50%;">
                <h3 style="font-size: 24px">Price Quotation</h3>
            </td>
            <td style="width: 50%; text-align: right;">
                @if($quotation->logo == 'Esmart')
                    <img src="<?php echo public_path('images/pdf/pdf_logo2.png'); ?>" style="width: 180px">
                @else
                    <img src="<?php echo public_path('images/pdf/Asset 1.png'); ?>" style="width: 180px">
                @endif
            </td>
        </tr>
        <tr>
            <td style="line-height: 20px; border:1px solid #000000;padding: 10px 10px 10px 5px">
                <p><strong>Name:-</strong> {{ $quotation->customers['name'] }}</p>
                <p><strong>Address:-</strong> {{ $quotation->customers['address'] }}, {{ $quotation->customers['city'] }}, {{ $quotation->customers['country'] }}</p>
                <p><strong>Email:-</strong> {{ $quotation->customers['email'] }}</p>
                <p>
                    <strong>Contact Person: </strong> {{$quotation->customers['contact_name']}}
                </p>
                <p><strong>Phone:-</strong>
                    @if(!empty($quotation->phone_number))
                        {{$quotation->phone_number}}
                    @else
                        {{ $quotation->customers['phone_number'] }}
                    @endif
                </p>
            </td>
            <td style="text-align: right;line-height: 20px;padding-top: 10px">
                <p>House no 1/A, Flat B2</p>
                <p>Eskaton Garden Road, Dhaka 1000</p>
                <p><strong>Hotline:</strong> 0961778877, 01316448804</p>
                <p><strong>Email:</strong> query@esmart.com.bd</p>
                <p><strong>Website:</strong> https://esmart.com.bd</p>
            </td>
        </tr>
        <tr>
            <td style="font-size:16px; padding-top:10px ; ">
                <p><strong>Quotation No:</strong>{{ $quotation->quotation_number }}</p>
            </td>
            <td style="text-align: right; font-size:16px">
                <?php $date = \Carbon\Carbon::now()->format('d M, Y'); ?>
                <p><strong> {{ $date }}</strong></p>
            </td>
        </tr>
        <tr>
            <td colspan="8">
                <p>Dear, <br>
                    <strong>{{ $quotation->customers['name'] }}</strong></p>
                <p style="margin-bottom: 10px">
                    Upon your request for a quotation, here we enclose our price quotation offer for
                    <?php
                    $products = json_decode($quotation->products, true);
                    foreach ($products as $product) {
                        echo $product['product_name'] . ', ';
                    }
                    ?>
                </p>
            </td>
        </tr>
    </table>

    <table style="border-collapse: collapse; width: 100%;">
        <thead>
        <tr>
            <th style="border: 1px solid #304051; padding: 8px;">SL</th>
            <th style="border: 1px solid #304051; padding: 8px;">Product Name</th>
            <th style="border: 1px solid #304051; padding: 8px;">Product Code</th>
            <th style="border: 1px solid #304051; padding: 8px;">Description</th>
            <th style="border: 1px solid #304051; padding: 8px;">QT</th>
            <th style="border: 1px solid #304051; padding: 8px;">Unit Price</th>
            <th style="border: 1px solid #304051; padding: 8px;">Total Price</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $totalPrice = 0;
        $products = json_decode($quotation->products, true);
        foreach ($products as $key => $product) {
        $priceWithVat = floatval($product['unit_price']) + floatval($product['unit_price']) * floatval( $quotation->vat_tax) / 100;
        $totalPrice += floatval($priceWithVat) * floatval($product['quantity']);
        ?>
        <tr>
            <td style="border: 1px solid #304051; padding: 8px;"><?php echo $key + 1; ?></td>
            <td style="border: 1px solid #304051; padding: 8px;"><?php echo $product['product_name']; ?></td>
            <td style="border: 1px solid #304051; padding: 8px;"><?php echo $product['product_code']; ?></td>
            <td style="border: 1px solid #304051; padding: 8px;"><?php echo $product['description']; ?></td>
            <td style="border: 1px solid #304051; padding: 8px;"><?php echo $product['quantity'],' '.$product['unit']; ?></td>
            <td style="border: 1px solid #304051; padding: 8px;"><?php echo $priceWithVat; ?></td>
            <td style="border: 1px solid #304051; padding: 8px;"><?php echo number_format($priceWithVat * floatval($product['quantity']),2,'.',''); ?></td>
        </tr>
        <?php } ?>
        </tbody>
        <tfoot>
        @if(!empty($quotation->delivery_check))
            <tr>
                <td colspan="6" style="text-align: right; border: 1px solid #304051; padding: 8px;">
                    <strong>Delivery Charge Include</strong><br>
                    <span style="font-size: 12px">
                        @if(!empty($quotation->delivery_check))
                              (Delivery Charge Applicable)
                        @else
                            (Delivery Charge Not Applicable)
                        @endif
                    </span>
                </td>
                <td style="border: 1px solid #304051; padding: 8px;">
                    <?php
                        $deliveryCharge = number_format( preg_replace('/[^0-9]/', '', $quotation->delivery_charge),2,'.','') ;
                        echo $deliveryCharge.' '.(preg_replace('/[0-9]/', '', $quotation->delivery_charge));
                    ?>
                </td>
            </tr>

        @else
            <tr>
                <td colspan="6" style="text-align: right; border: 1px solid #304051; padding: 8px;">

                    <span style="font-size: 14px">
                        (Delivery Charge Not Applicable)
                    </span>
                </td>
                <td style="border: 1px solid #304051; padding: 8px;">
                    00.00
                </td>
            </tr>
        @endif
        @if($quotation->extra_amount)
            <tr>
                <td colspan="6" style="text-align: right; border: 1px solid #304051; padding: 8px;">
                    <strong>{{$quotation->extra_charge_name}}</strong>
                </td>
                <td style="border: 1px solid #304051; padding: 8px;">
                    {{$quotation->extra_amount}}
                </td>
            </tr>
        @endif
        @if($quotation->discount_amount)
            <tr>
                <td colspan="6" style="text-align: right; border: 1px solid #304051; padding: 8px;">
                    <strong>Discount</strong>
                </td>
                <td style="border: 1px solid #304051; padding: 8px;">
                    -{{$quotation->discount_amount}}
                </td>
            </tr>
        @endif
        <tr>
            <td colspan="6" style="text-align: right; border: 1px solid #304051; padding: 8px;">
                <strong>Total:</strong>
            </td>
            <td style="border: 1px solid #304051; padding: 8px;">
                <?php
                $deliveryCharge = floatval($quotation->delivery_charge);
                $extraAmount = floatval($quotation->extra_amount);
                $discountAmount = floatval($quotation->discount_amount); // Add a semicolon at the end of this line

                $totalPrice = $totalPrice + ($deliveryCharge ?? 0) + ($extraAmount ?? 0) - ($discountAmount ?? 0);
                echo number_format($totalPrice,2,'.','');
                ?>
            </td>
        </tr>
        </tfoot>
    </table>

    <p>
        <strong>Total Price (In Words):</strong>   <?php
        $numberFormatter = new NumberFormatter("en", NumberFormatter::SPELLOUT);
        $totalPrice = ceil($totalPrice);
        $totalPriceInWords = ucwords($numberFormatter->format($totalPrice));
        echo $totalPriceInWords.' Tk. Only';
        ?>

    </p>
    <div class="quotation-foot">
        <p><strong>Terms & Conditions</strong></p>
        <p>
            <strong>Payment Method:</strong> {{$quotation->payment_type}}<br>
            <span>(Conquest Impex, Islami Bank Bangladesh Limited, Moghbazar branch, A/C: 20503320100150001)</span>
        </p>

        @if(!empty($quotation->offer_validity))
            <p>
                <strong>Offer Validity:</strong> {{$quotation->offer_validity}} Days
            </p>
        @endif
        @if($quotation->vat_tax == 7.5)
            <strong>Vat include 7.5%</strong>
        @elseif($quotation->vat_tax == 3)
            <strong>
                Ait Include 3%
            </strong>
        @else
            <strong>Vat & Ait: Exclude</strong>
        @endif
        <p>
            <strong>Delivery Term:</strong> {{$quotation->delivery_term}}
        </p>
        @php
            $deliveryTime = \Carbon\Carbon::now()->diffInWeekdays($quotation->delivery_date)
        @endphp

        @if($deliveryTime > 0)
            <p>
                <strong>Delivery Time:</strong> Within {{ $deliveryTime }} working days
            </p>
        @elseif( $deliveryTime == 0)
            <strong>Delivery Time:</strong> Today
        @endif

        @if(!empty($quotation->other_condition))
            <p>
                <strong>Other Condition:</strong> {{$quotation->other_condition}}
            </p>
        @endif
        <div style="line-height: 8px;">
            <img src="{{public_path('images/pdf/seal_logo2-1.jpeg')}}" style="width: 120px">
            <p>Best Regards</p>
            <p>{{$quotation->users['name']}}</p>
            <p>Business Development Executive</p>
        </div>
        <div style="line-height: 8px">
            @if($quotation->logo == 'Esmart')
                <img src="<?php echo public_path('images/pdf/pdf_logo2.png'); ?>" style="width: 180px">
                <p>eSmart Bangladesh</p>
                <p>House no 1/A, Flat B2</p>
            @else
                <img src="<?php echo public_path('images/pdf/Asset 1.png'); ?>" style="width: 180px">
                <p>Conquest Impex Bangladesh</p>
                <p>House no 1/A, Flat B2</p>
            @endif

        </div>
    </div>

</div>
</body>
</html>
